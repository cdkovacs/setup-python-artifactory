#!/usr/bin/env bash
set -euo pipefail
: "${RUNNER_TOOL_CACHE:?RUNNER_TOOL_CACHE must be set by the action runtime}"

# The version + arch are baked in at fixture-build time below.
VERSION="3.11.99"
ARCH="x64"

DEST="$RUNNER_TOOL_CACHE/Python/$VERSION/$ARCH"
mkdir -p "$DEST"

# Copy payload (tool/*) into the destination.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp -R "$SCRIPT_DIR/tool/." "$DEST/"

# tc.find() looks for {DEST}.complete to consider a tool installed.
touch "$RUNNER_TOOL_CACHE/Python/$VERSION/$ARCH.complete"

echo "[fixture setup.sh] Installed Python $VERSION to $DEST"
